﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Check if the correct number of command-line arguments is provided
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: menupermissions <users_file> <menus_file>");
            return;
        }

        // Extract file paths from command-line arguments
        string ss_usersFile = args[0];
        string ss_menusFile = args[1];

        // Check if input files exist
        if (!File.Exists(ss_usersFile) || !File.Exists(ss_menusFile))
        {
            Console.WriteLine("Invalid file paths.");
            return;
        }

        // Read user permissions from users file
        Dictionary<string, List<bool>> ss_userPermissions = ReadUserPermissions(ss_usersFile);

        // Read menu items from menus file
        List<string> ss_menuItems = ReadMenuItems(ss_menusFile);

        // Match user permissions with menu items
        List<UserMenuPermissions> ss_userMenuPermissions = GetUserMenuPermissions(ss_userPermissions, ss_menuItems);

        // Output the result as JSON
        OutputJson(ss_userMenuPermissions);
    }

    // Read user permissions from a file and parse them into a dictionary
    static Dictionary<string, List<bool>> ReadUserPermissions(string ss_filePath)
    {
        Dictionary<string, List<bool>> ss_userPermissions = new Dictionary<string, List<bool>>();

        foreach (string ss_line in File.ReadLines(ss_filePath))
        {
            // Split each line into username and permissions
            string[] ss_parts = ss_line.Split(' ');
            string ss_userName = ss_parts[0];
            List<bool> ss_permissions = ss_parts[1].Select(c => c == 'Y').ToList();
            ss_userPermissions[ss_userName] = ss_permissions;
        }

        return ss_userPermissions;
    }

    // Read menu items from a file and return them as a list
    static List<string> ReadMenuItems(string ss_filePath)
    {
        List<string> ss_menuItems = new List<string>();

        foreach (string ss_line in File.ReadLines(ss_filePath))
        {
            // Split each line into menu ID and menu name, then add the menu name to the list
            string[] ss_parts = ss_line.Split(',');
            ss_menuItems.Add(ss_parts[1].Trim());
        }

        return ss_menuItems;
    }

    // Match user permissions with menu items and generate user-menu permissions objects
    static List<UserMenuPermissions> GetUserMenuPermissions(Dictionary<string, List<bool>> ss_userPermissions, List<string> ss_menuItems)
    {
        List<UserMenuPermissions> ss_userMenuPermissions = new List<UserMenuPermissions>();

        foreach (var ss_user in ss_userPermissions)
        {
            var ss_userPermission = new UserMenuPermissions
            {
                UserName = ss_user.Key,
                MenuItems = new List<string>()
            };

            for (int ss_i = 0; ss_i < ss_user.Value.Count; ss_i++)
            {
                // If the user has permission for a menu item, add it to the user's menu items
                if (ss_user.Value[ss_i])
                {
                    ss_userPermission.MenuItems.Add(ss_menuItems[ss_i]);
                }
            }

            ss_userMenuPermissions.Add(ss_userPermission);
        }

        return ss_userMenuPermissions;
    }

    // Output the user-menu permissions as JSON
    static void OutputJson(List<UserMenuPermissions> ss_userMenuPermissions)
    {
        var ss_output = new
        {
            users = ss_userMenuPermissions.Select(ss_user =>
                new
                {
                    userName = ss_user.UserName,
                    menuItems = ss_user.MenuItems
                }
            )
        };

        Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(ss_output, Newtonsoft.Json.Formatting.Indented));
        Console.ReadLine();
    }
}

// Class to represent user-menu permissions
class UserMenuPermissions
{
    public string UserName { get; set; }
    public List<string> MenuItems { get; set; }
}
