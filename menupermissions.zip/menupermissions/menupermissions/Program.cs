﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Check if the correct number of command-line arguments is provided
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: menupermissions <users_file> <menus_file>");
            return;
        }

        // Extract file paths from command-line arguments
        string usersFile = args[0];
        string menusFile = args[1];

        // Check if input files exist
        if (!File.Exists(usersFile) || !File.Exists(menusFile))
        {
            Console.WriteLine("Invalid file paths.");
            return;
        }

        // Read user permissions from users file
        Dictionary<string, List<bool>> userPermissions = ReadUserPermissions(usersFile);

        // Read menu items from menus file
        List<string> menuItems = ReadMenuItems(menusFile);

        // Match user permissions with menu items
        List<UserMenuPermissions> userMenuPermissions = GetUserMenuPermissions(userPermissions, menuItems);

        // Output the result as JSON
        OutputJson(userMenuPermissions);
    }

    // Read user permissions from a file and parse them into a dictionary
    static Dictionary<string, List<bool>> ReadUserPermissions(string filePath)
    {
        Dictionary<string, List<bool>> userPermissions = new Dictionary<string, List<bool>>();

        foreach (string line in File.ReadLines(filePath))
        {
            // Split each line into username and permissions
            string[] parts = line.Split(' ');
            string userName = parts[0];
            List<bool> permissions = parts[1].Select(c => c == 'Y').ToList();
            userPermissions[userName] = permissions;
        }

        return userPermissions;
    }

    // Read menu items from a file and return them as a list
    static List<string> ReadMenuItems(string filePath)
    {
        List<string> menuItems = new List<string>();

        foreach (string line in File.ReadLines(filePath))
        {
            // Split each line into menu ID and menu name, then add the menu name to the list
            string[] parts = line.Split(',');
            menuItems.Add(parts[1].Trim());
        }

        return menuItems;
    }

    // Match user permissions with menu items and generate user-menu permissions objects
    static List<UserMenuPermissions> GetUserMenuPermissions(Dictionary<string, List<bool>> userPermissions, List<string> menuItems)
    {
        List<UserMenuPermissions> userMenuPermissions = new List<UserMenuPermissions>();

        foreach (var user in userPermissions)
        {
            var userPermission = new UserMenuPermissions
            {
                UserName = user.Key,
                MenuItems = new List<string>()
            };

            for (int i = 0; i < user.Value.Count; i++)
            {
                // If the user has permission for a menu item, add it to the user's menu items
                if (user.Value[i])
                {
                    userPermission.MenuItems.Add(menuItems[i]);
                }
            }

            userMenuPermissions.Add(userPermission);
        }

        return userMenuPermissions;
    }

    // Output the user-menu permissions as JSON
    static void OutputJson(List<UserMenuPermissions> userMenuPermissions)
    {
        var output = new
        {
            users = userMenuPermissions.Select(user =>
                new
                {
                    userName = user.UserName,
                    menuItems = user.MenuItems
                }
            )
        };

        Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(output, Newtonsoft.Json.Formatting.Indented));
        Console.ReadLine();
    }
}

// Class to represent user-menu permissions
class UserMenuPermissions
{
    public string UserName { get; set; }
    public List<string> MenuItems { get; set; }
}
